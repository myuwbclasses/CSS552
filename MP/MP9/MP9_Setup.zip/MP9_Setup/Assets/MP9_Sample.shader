Shader"Custom/MP9_Sample"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
            // For displacement
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        Pass
        {
            Cull Off
            
            HLSLPROGRAM
            // Check out the many shader programs!
            #pragma vertex Vert
            #pragma hull Hull
            #pragma domain Domain
            #pragma geometry Geom
            #pragma fragment Frag

            #pragma target 5.0

            #include "UnityCG.cginc"
            #include "./TessShared/TessStruct.cginc"
            #include "./TessShared/TessControlFlags.cginc"
            
            sampler2D _MainTex;

            // Our own cleaner Vert Shader
            #include "./TessShared/VertShader.cginc"
            
            // Tessellation shaders
            #include "./TessShared/HullShader.cginc"
    
            // Assumption of the curve OC space
            static const float kCurveOffset = 5.0f; // start from (-5, 0, -5)
            static const float kCurveSize = 10.0f; // the whole curve covers 10 units in OC space

            // Only going to change this function
            #include "./TessShared/TessFunction.cginc"
            
            #include "./TessShared/DomainShader.cginc"

            // Almost all of the work is done here
            #include "./TessShared/GeomShader.cginc"


            #include "./TessShared/FragShader.cginc"            
            ENDHLSL
        }
    }
}
