﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TessControl : MonoBehaviour {
    const uint kComputeBezierX = 0x01 << 0;
    const uint kComputeBezierZ = 0x01 << 1;
    const uint kComputeMapDisplacement = 0x01 << 2;

    const uint kApplyScreenSpace = 0x01 << 7;
    const uint kApplyOC = 0x01 << 8;


    public enum FragShowMode
    {
        eShowUnshadedTexture = 0x01 << 10,
        eShowShadedTexture = 0x01 << 11,
        eShowUV = 0x01 << 12,
        eShowNormal = 0x01 << 13,
        eShowLightDir = 0x01 << 14,
        eShowNdotL = 0x01 << 15
    }
        public enum UseLightType
    {
        eDirectionalLight = 0x01 << 20,
        ePointLight = 0x01 << 21
    }

    public Transform LightInfo_Pt_Dir;
    [Header("Light Position/Direction")]
    public UseLightType LightType = UseLightType.ePointLight;

    [Header("Besier X/Z Control")]
    public bool ComputeBezierX = true;
    public bool ComputeBezierZ = true;
    [Range(0f, 1f)] public float XZBlendLambda = 0.5f; // 1 means fully X, 0 means fully Z
    [Range(0.1f, 5f)] public float NormalApproxDist = 0.05f;  
        // This is a percentage of kCurveSize (size is 10 by default), 0.1 is 0.1% of 10
    
    [Header("Map Displacement Control")]
    public bool ComputeMapDisplacement = false;
    [Range(0.01f, 4f)] public float HeightMapStrength = 1f; // Strength of height map displacement
    [Range(0, 10)] public int HeightMapLevel = 1; // Which level to sample for hieht map (0: is the base map, e.g., 9, is 2^9 filtered result)
    [Range(1, 10)] public int NormalApproxMapLevel = 2; // which level to sample for normal approximation

    [Header("Adaptive Tessellation Control")]
    public bool UseScreenSpaceTess = true; // If false, use OC space for tessellation control, which is independent from view and projection. If true, use screen space for tessellation control, which is view dependent.
    [Range(0.5f, 100f)] public float EdgeLength = 50f; // Desired edge length of triangle in screen space. The smaller, the more subdivision.
    public bool UseOCTess = false; // If true, use OC space for tessellation control, which is independent from view and projection. If false, use screen space for tessellation control, which is view dependent.
    [Range(5f, 60f)] public float EdgesPerCurveLength = 20f; // how many edgesto cover a peroid

    [Header("Fragment Debug Show")]
    public FragShowMode ShowMode = FragShowMode.eShowUnshadedTexture;
    
    private Material mat;


	// Use this for initialization
	void Start () {
        Debug.Assert(LightInfo_Pt_Dir != null, "Please assign the PointLightPos in inspector!");
        mat = GetComponent<MeshRenderer>().material;
        Debug.Log("Main Camera screen resolution: " + Camera.main.pixelWidth + "x" + Camera.main.pixelHeight);
    }

    // Update is called once per frame
    void Update () {
		uint mode = (uint)ShowMode | (uint)LightType;
        mode |= ComputeBezierX ? kComputeBezierX : 0;
        mode |= ComputeBezierZ ? kComputeBezierZ : 0;
        mode |= ComputeMapDisplacement ? kComputeMapDisplacement : 0;
        mode |= UseScreenSpaceTess ? (uint) kApplyScreenSpace : 0;
        mode |= UseOCTess ? (uint) kApplyOC : 0;

        mat.SetInt("_Flag", (int) mode);
        mat.SetFloat("_XZBlend", 1.0f-XZBlendLambda);        

        mat.SetFloat("_EdgeLength", EdgeLength);
        mat.SetFloat("_EdgesPerCurveLength", EdgesPerCurveLength);

        mat.SetFloat("_ScreenWidth", Camera.main.pixelWidth);
        mat.SetFloat("_ScreenHeight", Camera.main.pixelHeight);
        mat.SetFloat("_NormalApproxDist", NormalApproxDist);

        mat.SetFloat("_HeightMapStrength", HeightMapStrength);
        mat.SetInt("_HeightMapLevel", HeightMapLevel);  
        mat.SetInt("_NormalApproxMapLevel", NormalApproxMapLevel);
        
        if (LightType == UseLightType.eDirectionalLight) {
            mat.SetVector("_LightInfo", LightInfo_Pt_Dir.up);
        } else 
            mat.SetVector("_LightInfo", LightInfo_Pt_Dir.localPosition);
	}
}
