using System.Security.Cryptography.X509Certificates;
using UnityEditor.SceneManagement;
using UnityEditor.SearchService;
using UnityEngine;

public class CV_Profile : MonoBehaviour
{
    [Range(0.1f, 20f)] public float OCScale = 10f;
    public Vector3 OCDirection = Vector3.right;
    public string CVShaderName = "_XProfile";
    public Color ProfileColor = Color.red;

    const int kNumCVs = 4;

    GameObject mTheProfile = null;
        // dummy for collecting all the components

    Material  mTheTessMat = null;

    CV[] mCVs;

    Vector4[] mCVPos;  // 
    
    
    // Start is called before the first frame update
    void Start()
    {
        mTheTessMat = GetComponent<Renderer>().material;

        mTheProfile = new GameObject();
        mTheProfile.transform.SetParent(transform);
        
        mCVs = new CV[kNumCVs];
        // 
        OCDirection.Normalize();
        Vector3 delta = OCDirection * (OCScale/(kNumCVs-1));
        // Assume centered at the origin
        Vector3 pos = OCDirection * (-OCScale/2f);

        CV_Connector l = null;
        CV_Connector r = null;

        for (int i = 0; i<kNumCVs; i++) {
            if (i < kNumCVs-1)
                r = mTheProfile.AddComponent<CV_Connector>();
            mCVs[i] = mTheProfile.AddComponent<CV>();
            mCVs[i].InitCV(pos, OCDirection, ProfileColor, l, r);

            pos += delta;
            l = r;
            r = null;
        }

        for (int i = 4; i < kNumCVs; i++)
            mCVs[i].DisableCV();

        mCVPos = new Vector4[kNumCVs];
        UpdateCVPos();
    }

    // Update is called once per frame
    void Update()
    {
        UpdateCVPos();
        mTheTessMat.SetVectorArray(CVShaderName, mCVPos);
    }

    private void UpdateCVPos() {
        for (int i = 0; i<kNumCVs; i++) {
            Vector3 p = mCVs[i].GetCVPos();
            mCVPos[i] = new Vector4(p.x, p.y, p.z, 1);
        }
    }
}
