using UnityEngine;
using UnityEngine.PlayerLoop;

public class CV_Connector : MonoBehaviour
{
    const float kWidth = 0.05f;
    // Has two positions: Left and Right
    // Defines  a Cylinder connecting the positions
    GameObject mTheConnector = null;  // the cylinder
    Vector3 mLeftPos, mRightPos;  // the two positions
    
    // Start is called before the first frame update
    void Awake()
    {   
        mTheConnector = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        
        mTheConnector.name = "CV_Connector";
        mTheConnector.transform.SetParent(transform);
        
        mLeftPos = Vector3.up;
        mRightPos = Vector3.zero;
        UpdateConnector();
    }

    public void SetLeftPos(Vector3 p) { mLeftPos = p; UpdateConnector(); }
    public void SetRightPos(Vector3 p) { mRightPos = p; UpdateConnector(); }

    private void UpdateConnector() {
        Vector3 d = mLeftPos - mRightPos;
        float s = d.magnitude * 0.5f;
        mTheConnector.transform.localScale = new Vector3(kWidth, s, kWidth);
        mTheConnector.transform.localPosition = (mLeftPos + mRightPos)/2.0f;
        mTheConnector.transform.up = d;
    }

    public void DisableConnector() { mTheConnector.SetActive(false); }
}
