using Unity.Profiling;
using UnityEngine;

public class CV : MonoBehaviour
{
    // One CV, has two references to left and right CV_Connector+
    // CV itself is represented as a sphere
    GameObject mTheCV;
    CV_Connector mLeft, mRight;

    Vector3 MainDir;

    const float kSize = 0.5f;
    
    // Start is called before the first frame update
    void Awake()
    {
        mTheCV = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        mTheCV.transform.localScale = new Vector3(kSize, kSize, kSize);
        
        mTheCV.name = "CV";
        mTheCV.transform.SetParent(transform);
    }

    public void InitCV(Vector3 p, Vector3 dir, Color c, CV_Connector left, CV_Connector right) {
        MainDir = dir;  // direction that the CV is allowed to move
        SetCVPos(p);
        mLeft = left;
        mRight = right;
        mTheCV.GetComponent<Renderer>().material.color = c;
    }

    void Update() {
        Vector3 pos = Vector3.Dot(GetCVPos(), MainDir) * MainDir;
        pos.y = GetCVPos().y; // allow free movement in y direction
        SetCVPos(pos);
        if (mLeft != null) {
            mLeft.SetLeftPos(mTheCV.transform.localPosition);
        }

        if (mRight != null) {
            mRight.SetRightPos(mTheCV.transform.localPosition);
        }
    }

    public Vector4 GetCVPos() { return mTheCV.transform.localPosition; }
    public void SetCVPos(Vector3 p) { mTheCV.transform.localPosition = p; }

    public void DisableCV() { mTheCV.SetActive(false); mLeft.DisableConnector(); }
}
