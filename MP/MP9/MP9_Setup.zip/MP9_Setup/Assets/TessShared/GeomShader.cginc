#ifndef GEOM_SHADER
#define GEOM_SHADER


// Receives output from the Domain Shader, invoked one-triangle at a time    
[maxvertexcount(3)]  // We will perform cleanup, not going to do more
void Geom(triangle Domain2Geom input[3], inout TriangleStream<Geom2Frag> triStream)
{
    Geom2Frag o[3];

    for (int i = 0; i < 3; i++) {
        o[i].pcPos = input[i].pcPos;
        o[i].wcPos = mul(unity_ObjectToWorld, float4(input[i].ocPos, 1.0)).xyz; // Get the world space position from ocPos
        o[i].wcNormal = normalize(mul(input[i].ocNormal, (float3x3)unity_WorldToObject)); // Recompute the normal with slope approximation
        o[i].uv = input[i].uv;
    }

    // simply by-pass
    triStream.Append(o[0]);
    triStream.Append(o[1]);
    triStream.Append(o[2]);
    triStream.RestartStrip();
}
#endif // GEOM_SHADER