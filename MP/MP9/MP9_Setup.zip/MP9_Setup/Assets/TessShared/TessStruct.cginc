#ifndef TESS_STRUCT
#define TESS_STRUCT

// From Applicaiton to Vertex Shader
struct appdata  {
    float4 vertex : POSITION; // Vertex position in object space
    float3 normal : NORMAL; // Object space normal
    float3 tangent : TANGENT; // Object space tangent
    float2 uv : TEXCOORD0;
};

// From Vertex Shader to Hull Shader:
//    In reality, this struct will _not_ be so large
//    Only useful coordinates will be comptued and passed-on
//    Here, for conveniece sake, we simply pass everything, 
//    and do not worry about performance for now
struct Vert2Hull {
    float4 pcPos : POSITION; // Vertex position in Clip PC space
    float3 ocPos : TEXCOORD0; // Vertex position in Object space, for convenience
    float3 ocNormal : NORMAL; //  normal in OC space
    float3 ocTangent : TANGENT; // Tangent in OC space
    float2 uv : TEXCOORD1;
    
};

// Note: this strucutre is exactly the same as Vert2Hull
//       It is used to pass information from Hull shader to Domain shader
//       By giving these structuers different names, we can carefully examine
//       the order upon which shaders are invoked in the GPU
struct OutputFromHull {
    float4 pcPos : POSITION; // Vertex position in Clip PC space
    float3 ocPos : TEXCOORD0; // Vertex position in Object space, for convenience
    float3 ocNormal : NORMAL; //  normal in OC space
    float3 ocTangent : TANGENT; // Tangent in OC space
    float2 uv : TEXCOORD1;
};

// This structure, for a triangle is FIXED, 
// the number of edges is fixed, and the inside is also fixed,
struct TessFactor {
    float edges0 : SV_TessFactor0;     
    float edges1 : SV_TessFactor1;     
    float edges2 : SV_TessFactor2;     
        // The edges are HARD-Coded to related to the vertices!! BE careful!!
        // edges[0]: is V[1] to V[2]
        // edges[1]: is V[0] to V[2]
        // edges[2]: is V[0] to V[1]
    float inside : SV_InsideTessFactor; // approx: (inside)^2 is approx number of times a new triangle will be created
};

struct Domain2Geom {
    float4 pcPos : SV_POSITION; // Clip space position
    float3 ocPos : TEXCOORD0; // World space position
    float3 ocNormal : NORMAL; // World space normal
    float3 ocTangent : TANGENT; // World space tangent
    float2 uv : TEXCOORD1;
};

struct Geom2Frag {
    float4 pcPos : SV_POSITION; // Clip space position
    float3 wcPos : TEXCOORD0; // World space position
    float3 wcNormal : NORMAL; // World space normal
    float2 uv : TEXCOORD1;
};

// Barycentric interpolation for troangele vertices
float4 BCInterpolate(float4 p0, float4 p1, float4 p2, float3 bc) {
    return  p0 * bc.x + p1 * bc.y + p2 * bc.z;
}

float3 BCInterpolate(float3 p0, float3 p1, float3 p2, float3 bc) {
    return  p0 * bc.x + p1 * bc.y + p2 * bc.z;
}

float2 BCInterpolate(float2 p0, float2 p1, float2 p2, float3 bc) {
    return  p0 * bc.x + p1 * bc.y + p2 * bc.z;
}

float BCInterpolate(float p0, float p1, float p2, float3 bc) {
    return  p0 * bc.x + p1 * bc.y + p2 * bc.z;
}

#endif // TESS_STRUCT