#ifndef TESS_CONTROL_FLAGS
#define TESS_CONTROL_FLAGS

float3 _LightInfo; // in world space, and can be used as directional or point light depending on the flag
uint _Flag;
   
#define ModeIsSet(flag) ((_Flag & flag) != 0)

static const uint kComputeBezierX = 0x01 << 0;
static const uint kComputeBezierZ = 0x01 << 1;
static const uint kComputeMapDisplacement = 0x01 << 2;

static const uint kDebugNormalShowXHeightDelta = 0x01 << 5;
static const uint kDebugNormalShowZHeightDelta = 0x01 << 6;

static const uint kApplyScreenSpace = 0x01 << 7;
static const uint kApplyOC = 0x01 << 8;

static const uint kShowUnshadedTexture = 0x01 << 10;
static const uint kShowShadedTexture = 0x01 << 11;
static const uint kShowUV = 0x01 << 12;
static const uint kShowNormal = 0x01 << 13;
static const uint kShowLightDir = 0x01 << 14;
static const uint kShowNdotL = 0x01 << 15;

static const uint kUseDirectionalLight = 0x01 << 20;
static const uint kUsePointLight = 0x01 << 21;

#endif // TESS_CONTROL_FLAGS