#ifndef TESS_FUNCTION
#define TESS_FUNCTION


TessFactor ComputeTessFactor(InputPatch<Vert2Hull, 3> points)
{
    TessFactor o = (TessFactor)1;
    
    // Size of the edges
    // MUST Conform to what the hardware expects!
    // If you mixed up edge[index] and points[index]: shared vertex between 
    //     triangles will be subdivided differently, which will cause cracks in the mesh!
    //
    // edges[0]: is index 1 and 2
    o.edges0 = 2;

    // edges[1]: is index 0 and 2
    o.edges1 = 1; 

    // edges[2]: is index 0 and 1
    o.edges2 = 3;
    
    o.inside = (0.3 * (o.edges0 + o.edges1 + o.edges2)); // Heuristic for inside tessellation factor, almost average of edge subdivide
    return o;
}

#endif // TESS_FUNCTION